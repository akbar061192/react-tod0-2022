import React, { useState } from 'react';

const TaskItem = props => {
  const { taskItem, deleteTask, editTask, toggleTask } = props;
  const [currentTaskEdit, setCurrentTaskEdit] = useState(taskItem.task);
  const [isEditing, setIsEditing] = useState(false);

  const deleteItem = taskId => {
    deleteTask(taskId);
  };

  const handleEditChange = event => {
    setCurrentTaskEdit(event.target.value);
  };

  const handleEditTask = () => {
    editTask(taskItem.id, currentTaskEdit);
    setIsEditing(false);
  };

  const toggleItem = taskId => {
    toggleTask(taskId);
  };

  const currentTaskList = (
    <>
      <td className={taskItem.isCompleted ? 'completed' : ''} onClick={() => toggleItem(taskItem.id)}>
        <input type='checkbox' checked={taskItem.isCompleted} readOnly />
        <span className='task'>{taskItem.task}</span>
      </td>
      <td>
        <button onClick={() => setIsEditing(true)}>Edit</button>
        <button onClick={() => deleteItem(taskItem.id)}>Delete</button>
      </td>
    </>
  );

  const editingTask = (
    <>
      <td>
        <form>
          <input type='text' value={currentTaskEdit} onChange={handleEditChange} />
        </form>
      </td>
      <td>
        <button onClick={handleEditTask}>Save</button>
        <button onClick={() => setIsEditing(false)}>Cancel</button>
      </td>
    </>
  );

  return <tr>{isEditing ? editingTask : currentTaskList}</tr>;
};

export default TaskItem;
