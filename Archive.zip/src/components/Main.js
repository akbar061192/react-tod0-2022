import React, { useState } from 'react';
import CreateTask from './CreateTask';
import TaskList from './TaskList';

const Main = () => {
  const [tasks, setTasks] = useState([]);

  const createTask = newTask => {
    if (newTask.length === 0) {
      alert('Task cannot be empty');
      return;
    }
    setTasks(prevTasks => {
      return [...prevTasks, { id: Math.random(), task: newTask, isCompleted: false }];
    });
  };

  const deleteTask = taskId => {
    const tasksAfterDelete = tasks.filter(task => {
      return task.id !== taskId;
    });
    setTasks(tasksAfterDelete);
  };

  const editTask = (taskId, editedTask) => {
    const updatingEditedTask = tasks.map(task => {
      if (task.id === taskId) {
        return { ...task, task: editedTask };
      }
      return task;
    });
    setTasks(updatingEditedTask);
  };

  const toggleTask = taskId => {
    const tasksAfterToggle = tasks.map(task => {
      if (task.id === taskId) {
        return { ...task, isCompleted: !task.isCompleted };
      }
      return task;
    });
    setTasks(tasksAfterToggle);
  };

  return (
    <div className='main'>
      <h1>Todos</h1>
      <br />
      <div className='content'>
        <CreateTask createTask={createTask} />
        <br />
        <TaskList tasks={tasks} deleteTask={deleteTask} editTask={editTask} toggleTask={toggleTask} />
      </div>
    </div>
  );
};

export default Main;
