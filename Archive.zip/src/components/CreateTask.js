import React, { useState } from 'react';

const CreateTask = props => {
  const [task, setTask] = useState('');
  const { createTask } = props;

  const handleChange = event => {
    setTask(event.target.value);
  };

  const handleSubmit = event => {
    event.preventDefault();
    createTask(task);
    setTask('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type='text' placeholder='Enter a task' value={task} onChange={handleChange} />
      <button type='submit'>Add</button>
    </form>
  );
};

export default CreateTask;
