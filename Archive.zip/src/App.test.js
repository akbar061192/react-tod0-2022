import { render, screen, fireEvent } from '@testing-library/react';
import App from './App';

test('check the button has expected text and color before and after clicking', () => {
  render(<App />);
  const btn = screen.getByRole('button', { name: 'Change to blue' });
  expect(btn).toHaveStyle({ backgroundColor: 'red' });
  fireEvent.click(btn);
  expect(btn.textContent).toBe('Change to red');
  expect(btn).toHaveStyle({ backgroundColor: 'blue' });
});

test('check for initial button and checkbox condition', () => {
  render(<App />);
  const btn = screen.getByRole('button', { name: 'Change to blue' });
  expect(btn).toBeEnabled();
  const checkBox = screen.getByRole('checkbox');
  expect(checkBox).not.toBeChecked();
});

test('check for button disabled on checkbox click and enabled on 2nd click', () => {
  render(<App />);
  const btn = screen.getByRole('button', { name: 'Change to blue' });
  const checkBox = screen.getByRole('checkbox', { name: 'Disable button' });
  fireEvent.click(checkBox);
  expect(btn).toBeDisabled();
  fireEvent.click(checkBox);
  expect(btn).toBeEnabled();
});

test('button color is gray when checkbox is checked and red color on un-checked', () => {
  render(<App />);
  const btn = screen.getByRole('button', { name: 'Change to blue' });
  const checkBox = screen.getByRole('checkbox', { name: 'Disable button' });

  fireEvent.click(checkBox);
  expect(btn).toHaveStyle({ backgroundColor: 'gray' });

  fireEvent.click(checkBox);
  expect(btn).toHaveStyle({ backgroundColor: 'red' });
});

test('button color is gray on checbox click and the button reverts to blue on clicking checbox again and clicking button', () => {
  render(<App />);
  const btn = screen.getByRole('button', { name: 'Change to blue' });
  const checkBox = screen.getByRole('checkbox', { name: 'Disable button' });

  fireEvent.click(btn);

  fireEvent.click(checkBox);
  expect(btn).toHaveStyle({ backgroundColor: 'gray' });

  fireEvent.click(checkBox);
  expect(btn).toHaveStyle({ backgroundColor: 'blue' });
});
